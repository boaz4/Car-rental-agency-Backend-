/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.Program5;

/**
 *
 * @author boazd_000
 */
public class VINNotFoundException extends Exception
{
    public VINNotFoundException(String VIN)
    {
        System.out.println("This VIN: " + VIN + " was not found.");
    }
}
